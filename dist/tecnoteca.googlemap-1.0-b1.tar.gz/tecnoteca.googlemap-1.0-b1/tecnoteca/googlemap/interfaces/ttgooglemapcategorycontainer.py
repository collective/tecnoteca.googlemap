from zope import schema
from zope.interface import Interface

from tecnoteca.googlemap import googlemapMessageFactory as _


class ITTGoogleMapCategoryContainer(Interface):
    """Group of categories"""

    # -*- schema definition goes here -*-
